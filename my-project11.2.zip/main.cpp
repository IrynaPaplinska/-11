#include <iostream>
#include <cmath>
#include <iomanip> // Для форматованого виведення

// Функція, яка обчислює c, a та y
// Зауваження: в C++ функція повертає лише одне значення.
// Щоб повернути кілька (c, a, y), ми будемо передавати їх за посиланням (&)
// або використовувати структуру/кортеж. Тут використано посилання.
void calculate_trig_function(double k, double x, double &c, double &a, double &y) {
    
    // --- 1. Обчислення проміжної змінної c ---
    // c = arctan(|x|)
    // std::fabs(x) - обчислює модуль числа з плаваючою комою
    // std::atan(...) - обчислює арктангенс (результат в радіанах)
    c = std::atan(std::fabs(x));

    // --- 2. Обчислення проміжної змінної a ---
    // a = c + k^2
    a = c + k * k; // k*k швидше і простіше, ніж std::pow(k, 2)

    // --- 3. Обчислення кінцевої функції y ---
    // y = sin^3(a) + cos^2(x)

    // Обчислення sin^3(a) = (sin(a))^3
    double sin_a = std::sin(a);
    double sin_a_cubed = sin_a * sin_a * sin_a; // Або std::pow(sin_a, 3.0)

    // Обчислення cos^2(x) = (cos(x))^2
    double cos_x = std::cos(x);
    double cos_x_squared = cos_x * cos_x; // Або std::pow(cos_x, 2.0)

    y = sin_a_cubed + cos_x_squared;
}

int main() {
    // Встановлення локалі для коректної роботи з числами (наприклад, крапка замість коми)
    // та встановлення точності виводу
    std::cout << "🚀 Програма для обчислення y = sin^3(a) + cos^2(x) на C++" << std::endl;
    std::cout << std::fixed << std::setprecision(6); // Встановлення 6 знаків після коми

    double k_input, x_input;
    double c_result, a_result, y_result; // Змінні для збереження трьох результатів

    // Введення даних
    std::cout << "Введіть значення k: ";
    if (!(std::cin >> k_input)) {
        std::cerr << "❌ Помилка: Введено некоректне числове значення для k." << std::endl;
        return 1;
    }

    std::cout << "Введіть значення x: ";
    if (!(std::cin >> x_input)) {
        std::cerr << "❌ Помилка: Введено некоректне числове значення для x." << std::endl;
        return 1;
    }

    // Виклик функції: результати будуть записані в c_result, a_result, y_result
    calculate_trig_function(k_input, x_input, c_result, a_result, y_result);

    // Виведення результатів
    std::cout << "\n--- Результати обчислень ---" << std::endl;
    
    // 1. Результат c
    std::cout << "1. Проміжний результат c (в радіанах):" << std::endl;
    std::cout << "c = atan(|" << x_input << "|) = " << c_result << std::endl;

    // 2. Результат a
    std::cout << "2. Проміжний результат a:" << std::endl;
    std::cout << "a = c + k^2 = " << c_result << " + " << k_input << "^2 = " << a_result << std::endl;

    // 3. Результат y
    std::cout << "3. Кінцевий результат y:" << std::endl;
    std::cout << "y = sin^3(a) + cos^2(x) = " << y_result << std::endl;
    
    return 0;
}